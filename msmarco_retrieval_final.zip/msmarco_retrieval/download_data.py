import os
import tarfile
import requests

DATA_DIR = "data"
os.makedirs(DATA_DIR, exist_ok=True)
BASE = "https://msmarco.blob.core.windows.net/msmarcoranking/"


def download_file(url, output):
    if os.path.exists(output):
        print(f"Already exists: {output}")
        return
    print(f"Downloading {url}")
    r = requests.get(url, stream=True)
    r.raise_for_status()
    total = int(r.headers.get("content-length", 0))
    done = 0
    with open(output, "wb") as f:
        for chunk in r.iter_content(chunk_size=1024 * 1024):
            f.write(chunk)
            done += len(chunk)
            if total:
                print(f"\rProgress: {done / total * 100:.2f}%", end="")
    print()


def main():
    tar_path = os.path.join(DATA_DIR, "collectionandqueries.tar.gz")
    download_file(BASE + "collectionandqueries.tar.gz", tar_path)

    needed = ["collection.tsv", "queries.dev.tsv", "qrels.dev.tsv"]
    if not all(os.path.exists(os.path.join(DATA_DIR, n)) for n in needed):
        print("Extracting...")
        with tarfile.open(tar_path, "r:gz") as tar:
            tar.extractall(DATA_DIR)

    # qrels.dev.tsv is normally inside the tarball; fetch separately if not
    qrels = os.path.join(DATA_DIR, "qrels.dev.tsv")
    if not os.path.exists(qrels):
        download_file(BASE + "qrels.dev.tsv", qrels)

    for root, _, files in os.walk(DATA_DIR):
        for fn in files:
            print(os.path.join(root, fn))
    print("\nIf files ended up in a subfolder, move them into data/.")


if __name__ == "__main__":
    main()
