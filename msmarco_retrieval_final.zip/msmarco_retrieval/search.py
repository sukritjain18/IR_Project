import os
from src.config import *
from src.data_loader import load_subset
from src.tfidf_retriever import TFIDFRetriever
from src.bm25_retriever import BM25Retriever
from src.dense_retriever import DenseRetriever
from src.rrf import reciprocal_rank_fusion


class SearchEngine:
    def __init__(self):
        passages, _, _ = load_subset(COLLECTION_FILE, QUERIES_FILE, QRELS_FILE,
                                     MAX_PASSAGES, MAX_QUERIES)
        self.passages = passages.set_index("pid")

        self.tfidf = TFIDFRetriever()
        self.tfidf.load(os.path.join(INDEX_DIR, "tfidf"))

        self.bm25 = BM25Retriever()
        self.bm25.load(os.path.join(INDEX_DIR, "bm25"))

        self.dense = DenseRetriever(SENTENCE_MODEL)
        self.dense.load(os.path.join(INDEX_DIR, "sentence_transformer"))

        self.dpr = None
        dpr_dir = os.path.join(INDEX_DIR, "dpr")
        if os.path.exists(os.path.join(dpr_dir, "index.faiss")):
            import torch
            from src.dpr_retriever import DPRRetriever
            device = "cuda" if torch.cuda.is_available() else "cpu"
            self.dpr = DPRRetriever(DPR_QUESTION_MODEL, DPR_CONTEXT_MODEL, device)
            self.dpr.load(dpr_dir)

    def methods(self):
        m = ["hybrid", "bm25", "tfidf", "sentence"]
        return m + ["dpr"] if self.dpr else m

    def lookup_passage(self, pid):
        try:
            return self.passages.loc[str(pid), "text"]
        except KeyError:
            return "Passage not found."

    def search(self, query, method="hybrid", top_k=10):
        if method == "tfidf":
            results = self.tfidf.search(query, top_k)
        elif method == "bm25":
            results = self.bm25.search(query, top_k)
        elif method == "sentence":
            results = self.dense.search(query, top_k)
        elif method == "dpr":
            results = self.dpr.search(query, top_k)
        elif method == "hybrid":
            lists = {"tfidf": self.tfidf.search(query, 100),
                     "bm25": self.bm25.search(query, 100),
                     "sentence": self.dense.search(query, 100)}
            if self.dpr:
                lists["dpr"] = self.dpr.search(query, 100)
            results = reciprocal_rank_fusion(lists, k=RRF_K, top_k=top_k)
        else:
            raise ValueError(f"Unknown method: {method}")
        for r in results:
            r["text"] = self.lookup_passage(r["pid"])
        return results
