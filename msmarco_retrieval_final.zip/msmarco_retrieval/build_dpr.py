import os
import torch
from src.config import *
from src.data_loader import load_subset
from src.dpr_retriever import DPRRetriever


def main():
    passages, _, _ = load_subset(COLLECTION_FILE, QUERIES_FILE, QRELS_FILE,
                                 MAX_PASSAGES, MAX_QUERIES)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("Using device:", device)
    dpr = DPRRetriever(DPR_QUESTION_MODEL, DPR_CONTEXT_MODEL, device=device)
    dpr.build(passages, batch_size=EMBEDDING_BATCH_SIZE)
    dpr.save(os.path.join(INDEX_DIR, "dpr"))
    print("DPR index created.")


if __name__ == "__main__":
    main()
