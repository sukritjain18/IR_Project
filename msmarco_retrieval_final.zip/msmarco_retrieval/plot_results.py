import json
import matplotlib.pyplot as plt
import pandas as pd

df = pd.read_csv("results/metrics.csv")

ax = df.set_index("System")[["Precision@10", "Recall@10", "MAP", "nDCG@10"]].plot(
    kind="bar", figsize=(12, 7))
ax.set_title("MS MARCO Retrieval Performance")
ax.set_ylabel("Score")
plt.xticks(rotation=20)
plt.tight_layout()
plt.savefig("results/performance_comparison.png", dpi=300)

# True interpolated precision-recall curve (mean over queries)
with open("results/pr_curve_data.json") as f:
    curves = json.load(f)
plt.figure(figsize=(8, 6))
for system, ys in curves.items():
    plt.plot([i / (len(ys) - 1) for i in range(len(ys))], ys,
             marker="o", linewidth=2, label=system)
plt.xlabel("Recall")
plt.ylabel("Interpolated precision")
plt.title("Precision-Recall Curve (mean over queries)")
plt.grid(True, alpha=0.3)
plt.legend()
plt.tight_layout()
plt.savefig("results/pr_curve.png", dpi=300)
print("Saved results/performance_comparison.png and results/pr_curve.png")
