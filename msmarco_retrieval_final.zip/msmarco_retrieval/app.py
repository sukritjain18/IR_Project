import streamlit as st
from search import SearchEngine

st.set_page_config(page_title="MS MARCO Passage Retrieval", page_icon="🔎", layout="wide")


@st.cache_resource
def load_engine():
    return SearchEngine()


engine = load_engine()

st.title("🔎 MS MARCO Passage Retrieval")
st.markdown("Compare sparse, dense and hybrid retrieval: TF-IDF, BM25, "
            "Sentence Transformer, DPR (if indexed) and Hybrid RRF.")

query = st.text_input("Enter your search query:",
                      placeholder="Example: how does photosynthesis work?")
method = st.selectbox("Retrieval Model", engine.methods())
top_k = st.slider("Number of results", 1, 20, 10)

if st.button("Search", type="primary"):
    if not query.strip():
        st.warning("Please enter a query.")
    else:
        with st.spinner("Searching..."):
            results = engine.search(query, method=method, top_k=top_k)
        st.subheader(f"Results using {method}")
        for r in results:
            st.markdown(f"### #{r['rank']}\n\n**Passage ID:** `{r['pid']}`  \n"
                        f"**Score:** `{r['score']:.4f}`\n\n{r['text']}")
            st.divider()
