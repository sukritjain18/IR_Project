import os
import pickle
import numpy as np
from tqdm import tqdm
from rank_bm25 import BM25Okapi
from .preprocessing import tokenize


class BM25Retriever:
    def __init__(self):
        self.bm25 = None
        self.pids = []

    def fit(self, passages):
        print("Building BM25 index...")
        self.pids = passages["pid"].tolist()
        docs = [tokenize(t) for t in tqdm(passages["text"], desc="Tokenizing")]
        self.bm25 = BM25Okapi(docs)
        print("BM25 index built.")

    def search(self, query, top_k=10):
        scores = np.asarray(self.bm25.get_scores(tokenize(query)))
        if top_k >= len(scores):
            idx = np.argsort(-scores)
        else:
            idx = np.argpartition(-scores, top_k)[:top_k]
            idx = idx[np.argsort(-scores[idx])]
        return [{"pid": self.pids[i], "score": float(scores[i]), "rank": r}
                for r, i in enumerate(idx, start=1)]

    def save(self, directory):
        os.makedirs(directory, exist_ok=True)
        with open(os.path.join(directory, "bm25.pkl"), "wb") as f:
            pickle.dump(self.bm25, f)
        with open(os.path.join(directory, "pids.pkl"), "wb") as f:
            pickle.dump(self.pids, f)

    def load(self, directory):
        with open(os.path.join(directory, "bm25.pkl"), "rb") as f:
            self.bm25 = pickle.load(f)
        with open(os.path.join(directory, "pids.pkl"), "rb") as f:
            self.pids = pickle.load(f)
