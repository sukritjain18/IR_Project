import os
import pandas as pd
from tqdm import tqdm


def load_queries(path):
    queries = {}
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            parts = line.rstrip("\n").split("\t", maxsplit=1)
            if len(parts) == 2:
                queries[str(parts[0])] = parts[1]
    return queries


def load_qrels(path):
    qrels = {}
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            parts = line.rstrip("\n").split("\t")
            if len(parts) < 4:
                continue
            qrels.setdefault(str(parts[0]), {})[str(parts[2])] = int(parts[3])
    return qrels


def load_collection(path, max_passages=None, must_include=None):
    """Load first `max_passages` passages plus every pid in `must_include`."""
    must_include = must_include or set()
    records = []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for i, line in enumerate(tqdm(f, desc="Reading collection")):
            parts = line.rstrip("\n").split("\t", maxsplit=1)
            if len(parts) != 2:
                continue
            pid, text = str(parts[0]), parts[1]
            in_head = max_passages is None or i < max_passages
            if in_head or pid in must_include:
                records.append({"pid": pid, "text": text})
            elif max_passages is not None and len(must_include) == 0:
                break
    return pd.DataFrame(records)


def load_subset(collection_path, queries_path, qrels_path,
                max_passages=None, max_queries=None, cache_dir="data"):
    """
    Returns (passages_df, queries, qrels) for a consistent evaluation subset.
    Cached on disk so every script sees exactly the same passages.
    """
    queries = load_queries(queries_path)
    qrels = load_qrels(qrels_path)
    qids = [q for q in queries if q in qrels]
    if max_queries is not None:
        qids = qids[:max_queries]
    queries = {q: queries[q] for q in qids}
    qrels = {q: qrels[q] for q in qids}

    if max_passages is None:
        return load_collection(collection_path), queries, qrels

    cache = os.path.join(cache_dir, f"subset_{max_passages}_{max_queries}.tsv")
    if os.path.exists(cache):
        df = pd.read_csv(cache, sep="\t", dtype={"pid": str},
                         keep_default_na=False)
        return df, queries, qrels

    must = {p for q in qrels.values() for p in q}
    df = load_collection(collection_path, max_passages, must)
    df.to_csv(cache, sep="\t", index=False)
    return df, queries, qrels
