from collections import defaultdict


def reciprocal_rank_fusion(result_lists, k=60, top_k=10):
    """RRF(d) = sum_m 1 / (k + rank_m(d))"""
    scores = defaultdict(float)
    for results in result_lists.values():
        for r in results:
            scores[r["pid"]] += 1.0 / (k + r["rank"])
    ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:top_k]
    return [{"pid": pid, "score": s, "rank": i}
            for i, (pid, s) in enumerate(ranked, start=1)]
