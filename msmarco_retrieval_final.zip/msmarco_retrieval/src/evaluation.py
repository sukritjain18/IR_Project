import math
import numpy as np


def _relevant(qrels):
    return {p for p, r in qrels.items() if r > 0}


def precision_at_k(results, qrels, k=10):
    rel = _relevant(qrels)
    return sum(r["pid"] in rel for r in results[:k]) / k


def recall_at_k(results, qrels, k=10):
    rel = _relevant(qrels)
    if not rel:
        return 0.0
    return sum(r["pid"] in rel for r in results[:k]) / len(rel)


def average_precision(results, qrels):
    rel = _relevant(qrels)
    if not rel:
        return 0.0
    hits, total = 0, 0.0
    for rank, r in enumerate(results, start=1):
        if r["pid"] in rel:
            hits += 1
            total += hits / rank
    return total / len(rel)


def ndcg_at_k(results, qrels, k=10):
    dcg = sum((2 ** qrels.get(r["pid"], 0) - 1) / math.log2(i + 1)
              for i, r in enumerate(results[:k], start=1))
    ideal = sorted(qrels.values(), reverse=True)[:k]
    idcg = sum((2 ** rel - 1) / math.log2(i + 1)
               for i, rel in enumerate(ideal, start=1))
    return dcg / idcg if idcg else 0.0


def interpolated_pr(results, qrels, levels=11):
    """Interpolated precision at recall 0.0, 0.1, ... 1.0 for one query."""
    rel = _relevant(qrels)
    pts, hits = [], 0
    for rank, r in enumerate(results, start=1):
        if r["pid"] in rel:
            hits += 1
            pts.append((hits / len(rel), hits / rank))
    out = []
    for i in range(levels):
        lvl = i / (levels - 1)
        out.append(max([p for rc, p in pts if rc >= lvl], default=0.0))
    return out


def evaluate_query(results, qrels):
    return {
        "Precision@10": precision_at_k(results, qrels, 10),
        "Recall@10": recall_at_k(results, qrels, 10),
        "Recall@1000": recall_at_k(results, qrels, 1000),
        "MAP": average_precision(results, qrels),
        "nDCG@10": ndcg_at_k(results, qrels, 10),
    }


def evaluate_system(system_results, qrels):
    rows = [evaluate_query(res, qrels[qid])
            for qid, res in system_results.items() if qid in qrels]
    if not rows:
        return {}
    return {k: float(np.mean([r[k] for r in rows])) for k in rows[0]}


def mean_pr_curve(system_results, qrels):
    curves = [interpolated_pr(res, qrels[qid])
              for qid, res in system_results.items() if qid in qrels]
    return np.mean(curves, axis=0).tolist()
