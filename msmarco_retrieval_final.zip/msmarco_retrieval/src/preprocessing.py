import re
import nltk
from nltk.corpus import stopwords
from nltk.stem import SnowballStemmer

try:
    stopwords.words("english")
except LookupError:
    nltk.download("stopwords")

STOP_WORDS = set(stopwords.words("english"))
STEMMER = SnowballStemmer("english")


def clean_text(text):
    if not isinstance(text, str):
        return ""
    text = text.lower()
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def tokenize(text):
    tokens = clean_text(text).split()
    tokens = [t for t in tokens if t not in STOP_WORDS]
    return [STEMMER.stem(t) for t in tokens]


def preprocess(text):
    return " ".join(tokenize(text))
