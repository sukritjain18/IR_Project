import os
import sys
sys.path.append(".")

from src.config import *
from src.data_loader import load_subset
from src.tfidf_retriever import TFIDFRetriever
from src.bm25_retriever import BM25Retriever
from src.dense_retriever import DenseRetriever


def main():
    os.makedirs(INDEX_DIR, exist_ok=True)
    passages, _, _ = load_subset(COLLECTION_FILE, QUERIES_FILE, QRELS_FILE,
                                 MAX_PASSAGES, MAX_QUERIES)
    print("Number of passages:", len(passages))

    print("\n========== TF-IDF ==========")
    tfidf = TFIDFRetriever()
    tfidf.fit(passages)
    tfidf.save(os.path.join(INDEX_DIR, "tfidf"))

    print("\n========== BM25 ==========")
    bm25 = BM25Retriever()
    bm25.fit(passages)
    bm25.save(os.path.join(INDEX_DIR, "bm25"))

    print("\n========== Sentence Transformer ==========")
    dense = DenseRetriever(SENTENCE_MODEL)
    dense.build(passages, batch_size=EMBEDDING_BATCH_SIZE)
    dense.save(os.path.join(INDEX_DIR, "sentence_transformer"))

    print("\nAll indexes created successfully.")


if __name__ == "__main__":
    main()
