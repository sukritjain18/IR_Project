import os

DATA_DIR = "data"
INDEX_DIR = "indexes"
RESULT_DIR = "results"

COLLECTION_FILE = os.path.join(DATA_DIR, "collection.tsv")
QUERIES_FILE = os.path.join(DATA_DIR, "queries.dev.tsv")
QRELS_FILE = os.path.join(DATA_DIR, "qrels.dev.tsv")

# Subset size. Relevant passages of the selected dev queries are ALWAYS
# included, the rest is filled with the first passages of the collection.
# Use 50000 -> 100000 -> None (full corpus, see README).
MAX_PASSAGES = 100000

# Number of dev queries to evaluate (None = all queries with qrels).
MAX_QUERIES = 500

TOP_K = 100
EVAL_K = 10

SENTENCE_MODEL = "sentence-transformers/msmarco-distilbert-base-tas-b"
DPR_QUESTION_MODEL = "facebook/dpr-question_encoder-single-nq-base"
DPR_CONTEXT_MODEL = "facebook/dpr-ctx_encoder-single-nq-base"

EMBEDDING_BATCH_SIZE = 32
RRF_K = 60
