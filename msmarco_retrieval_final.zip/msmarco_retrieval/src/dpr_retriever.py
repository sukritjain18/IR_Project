import os
import pickle
import faiss
import numpy as np
import torch
from tqdm import tqdm
from transformers import (DPRQuestionEncoder, DPRQuestionEncoderTokenizer,
                          DPRContextEncoder, DPRContextEncoderTokenizer)


class DPRRetriever:
    def __init__(self, question_model, context_model, device="cpu"):
        self.device = device
        self.q_tok = DPRQuestionEncoderTokenizer.from_pretrained(question_model)
        self.q_enc = DPRQuestionEncoder.from_pretrained(question_model).to(device).eval()
        self.c_tok = DPRContextEncoderTokenizer.from_pretrained(context_model)
        self.c_enc = DPRContextEncoder.from_pretrained(context_model).to(device).eval()
        self.index = None
        self.pids = []

    def encode_documents(self, texts, batch_size=16):
        out = []
        for s in tqdm(range(0, len(texts), batch_size), desc="DPR passages"):
            enc = self.c_tok(texts[s:s + batch_size], padding=True,
                             truncation=True, max_length=256,
                             return_tensors="pt")
            enc = {k: v.to(self.device) for k, v in enc.items()}
            with torch.no_grad():
                out.append(self.c_enc(**enc).pooler_output.cpu().numpy())
        return np.vstack(out)

    def encode_query(self, query):
        enc = self.q_tok([query], padding=True, truncation=True,
                         max_length=64, return_tensors="pt")
        enc = {k: v.to(self.device) for k, v in enc.items()}
        with torch.no_grad():
            return self.q_enc(**enc).pooler_output.cpu().numpy()

    def build(self, passages, batch_size=16):
        self.pids = passages["pid"].tolist()
        emb = self.encode_documents(passages["text"].tolist(), batch_size)
        emb = emb.astype("float32")
        self.index = faiss.IndexFlatIP(emb.shape[1])
        self.index.add(emb)

    def search(self, query, top_k=10):
        q = self.encode_query(query).astype("float32")
        scores, idx = self.index.search(q, top_k)
        return [{"pid": self.pids[i], "score": float(s), "rank": r}
                for r, (i, s) in enumerate(zip(idx[0], scores[0]), start=1)
                if i != -1]

    def save(self, directory):
        os.makedirs(directory, exist_ok=True)
        faiss.write_index(self.index, os.path.join(directory, "index.faiss"))
        with open(os.path.join(directory, "pids.pkl"), "wb") as f:
            pickle.dump(self.pids, f)

    def load(self, directory):
        self.index = faiss.read_index(os.path.join(directory, "index.faiss"))
        with open(os.path.join(directory, "pids.pkl"), "rb") as f:
            self.pids = pickle.load(f)
