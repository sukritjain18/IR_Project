import os
import pickle
import numpy as np
from scipy.sparse import save_npz, load_npz
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import normalize


def _top(scores, k):
    if k >= len(scores):
        return np.argsort(-scores)
    idx = np.argpartition(-scores, k)[:k]
    return idx[np.argsort(-scores[idx])]


class TFIDFRetriever:
    def __init__(self, max_features=300000):
        self.vectorizer = TfidfVectorizer(
            lowercase=True, stop_words="english", ngram_range=(1, 2),
            max_features=max_features, sublinear_tf=True)
        self.matrix = None
        self.pids = []

    def fit(self, passages):
        self.pids = passages["pid"].tolist()
        print("Building TF-IDF index...")
        self.matrix = normalize(
            self.vectorizer.fit_transform(passages["text"]), norm="l2")
        print("TF-IDF matrix shape:", self.matrix.shape)

    def search(self, query, top_k=10):
        qv = normalize(self.vectorizer.transform([query]), norm="l2")
        scores = (self.matrix @ qv.T).toarray().ravel()
        return [{"pid": self.pids[i], "score": float(scores[i]), "rank": r}
                for r, i in enumerate(_top(scores, top_k), start=1)]

    def save(self, directory):
        os.makedirs(directory, exist_ok=True)
        with open(os.path.join(directory, "vectorizer.pkl"), "wb") as f:
            pickle.dump(self.vectorizer, f)
        save_npz(os.path.join(directory, "matrix.npz"), self.matrix)
        with open(os.path.join(directory, "pids.pkl"), "wb") as f:
            pickle.dump(self.pids, f)

    def load(self, directory):
        with open(os.path.join(directory, "vectorizer.pkl"), "rb") as f:
            self.vectorizer = pickle.load(f)
        self.matrix = load_npz(os.path.join(directory, "matrix.npz"))
        with open(os.path.join(directory, "pids.pkl"), "rb") as f:
            self.pids = pickle.load(f)
