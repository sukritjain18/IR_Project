import os
import pickle
import faiss
from sentence_transformers import SentenceTransformer


class DenseRetriever:
    def __init__(self, model_name, device=None):
        self.model = SentenceTransformer(model_name, device=device)
        self.index = None
        self.pids = []

    def build(self, passages, batch_size=32, use_ivfpq=False):
        self.pids = passages["pid"].tolist()
        print("Encoding passages...")
        emb = self.model.encode(
            passages["text"].tolist(), batch_size=batch_size,
            show_progress_bar=True, convert_to_numpy=True,
            normalize_embeddings=True).astype("float32")
        dim = emb.shape[1]
        print("Embedding dimension:", dim)
        if use_ivfpq:  # for the full 8.8M corpus
            quantizer = faiss.IndexFlatIP(dim)
            self.index = faiss.IndexIVFPQ(quantizer, dim, 4096, 64, 8,
                                          faiss.METRIC_INNER_PRODUCT)
            self.index.train(emb[:min(100000, len(emb))])
            self.index.nprobe = 16
        else:
            self.index = faiss.IndexFlatIP(dim)
        self.index.add(emb)
        print("FAISS vectors:", self.index.ntotal)

    def search(self, query, top_k=10):
        q = self.model.encode([query], convert_to_numpy=True,
                              normalize_embeddings=True).astype("float32")
        scores, idx = self.index.search(q, top_k)
        return [{"pid": self.pids[i], "score": float(s), "rank": r}
                for r, (i, s) in enumerate(zip(idx[0], scores[0]), start=1)
                if i != -1]

    def save(self, directory):
        os.makedirs(directory, exist_ok=True)
        faiss.write_index(self.index, os.path.join(directory, "index.faiss"))
        with open(os.path.join(directory, "pids.pkl"), "wb") as f:
            pickle.dump(self.pids, f)

    def load(self, directory):
        self.index = faiss.read_index(os.path.join(directory, "index.faiss"))
        with open(os.path.join(directory, "pids.pkl"), "rb") as f:
            self.pids = pickle.load(f)
