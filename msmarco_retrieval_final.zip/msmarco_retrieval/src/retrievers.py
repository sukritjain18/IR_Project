"""Load all available retrievers from indexes/."""
import os
from .config import *
from .tfidf_retriever import TFIDFRetriever
from .bm25_retriever import BM25Retriever
from .dense_retriever import DenseRetriever


def load_all():
    r = {}
    t = TFIDFRetriever(); t.load(os.path.join(INDEX_DIR, "tfidf")); r["TF-IDF"] = t
    b = BM25Retriever(); b.load(os.path.join(INDEX_DIR, "bm25")); r["BM25"] = b
    d = DenseRetriever(SENTENCE_MODEL); d.load(os.path.join(INDEX_DIR, "sentence_transformer"))
    r["Sentence Transformer"] = d
    dpr_dir = os.path.join(INDEX_DIR, "dpr")
    if os.path.exists(os.path.join(dpr_dir, "index.faiss")):
        import torch
        from .dpr_retriever import DPRRetriever
        p = DPRRetriever(DPR_QUESTION_MODEL, DPR_CONTEXT_MODEL,
                         "cuda" if torch.cuda.is_available() else "cpu")
        p.load(dpr_dir); r["DPR"] = p
    else:
        print("DPR index not found - skipping DPR (run build_dpr.py).")
    return r
