# MS MARCO Passage Retrieval (TF-IDF, BM25, Sentence Transformer, DPR, Hybrid RRF)

## Setup
    python -m venv venv && source venv/bin/activate   # Windows: venv\Scripts\activate
    pip install -r requirements.txt

## Run order
    python download_data.py          # puts collection.tsv, queries.dev.tsv, qrels.dev.tsv in data/
    python -m src.build_indexes      # TF-IDF, BM25, Sentence Transformer
    python build_dpr.py              # DPR (slow; optional but needed for the DPR row)
    python evaluate.py               # -> results/metrics.csv, results/pr_curve_data.json
    python plot_results.py           # -> results/pr_curve.png, performance_comparison.png
    streamlit run app.py

## Settings (src/config.py)
- MAX_PASSAGES: 100000 by default. The relevant passages of the evaluated queries are always included.
- MAX_QUERIES: 500 dev queries by default (None = all).
- If you change either, delete data/subset_*.tsv and indexes/ and rebuild.

## Full 8.8M corpus
Don't just set MAX_PASSAGES=None. Use Pyserini for BM25, and `DenseRetriever.build(..., use_ivfpq=True)` for FAISS.
Report only numbers produced by your own run.
