import os
import json
import pandas as pd
from tqdm import tqdm

from src.config import *
from src.data_loader import load_subset
from src.evaluation import evaluate_system, mean_pr_curve
from src.tfidf_retriever import TFIDFRetriever
from src.bm25_retriever import BM25Retriever
from src.dense_retriever import DenseRetriever
from src.rrf import reciprocal_rank_fusion


def main():
    _, queries, qrels = load_subset(COLLECTION_FILE, QUERIES_FILE, QRELS_FILE,
                                    MAX_PASSAGES, MAX_QUERIES)
    print("Evaluating", len(queries), "queries")

    tfidf = TFIDFRetriever(); tfidf.load(os.path.join(INDEX_DIR, "tfidf"))
    bm25 = BM25Retriever(); bm25.load(os.path.join(INDEX_DIR, "bm25"))
    dense = DenseRetriever(SENTENCE_MODEL)
    dense.load(os.path.join(INDEX_DIR, "sentence_transformer"))

    dpr = None
    dpr_dir = os.path.join(INDEX_DIR, "dpr")
    if os.path.exists(os.path.join(dpr_dir, "index.faiss")):
        import torch
        from src.dpr_retriever import DPRRetriever
        device = "cuda" if torch.cuda.is_available() else "cpu"
        dpr = DPRRetriever(DPR_QUESTION_MODEL, DPR_CONTEXT_MODEL, device)
        dpr.load(dpr_dir)
    else:
        print("DPR index not found - skipping DPR (run build_dpr.py).")

    systems = ["TF-IDF", "BM25", "Sentence Transformer"]
    if dpr:
        systems.append("DPR")
    systems.append("Hybrid RRF")
    all_results = {s: {} for s in systems}

    for qid, query in tqdm(queries.items()):
        lists = {
            "tfidf": tfidf.search(query, 1000),
            "bm25": bm25.search(query, 1000),
            "sentence": dense.search(query, 1000),
        }
        all_results["TF-IDF"][qid] = lists["tfidf"]
        all_results["BM25"][qid] = lists["bm25"]
        all_results["Sentence Transformer"][qid] = lists["sentence"]
        if dpr:
            lists["dpr"] = dpr.search(query, 1000)
            all_results["DPR"][qid] = lists["dpr"]
        all_results["Hybrid RRF"][qid] = reciprocal_rank_fusion(
            lists, k=RRF_K, top_k=1000)

    rows, curves = [], {}
    for system, results in all_results.items():
        print("Evaluating", system)
        m = evaluate_system(results, qrels)
        m["System"] = system
        rows.append(m)
        curves[system] = mean_pr_curve(results, qrels)

    cols = ["System", "Precision@10", "Recall@10", "Recall@1000", "MAP", "nDCG@10"]
    df = pd.DataFrame(rows)[cols]
    os.makedirs(os.path.join(RESULT_DIR, "runs"), exist_ok=True)
    df.to_csv(os.path.join(RESULT_DIR, "metrics.csv"), index=False)
    with open(os.path.join(RESULT_DIR, "pr_curve_data.json"), "w") as f:
        json.dump(curves, f)

    print("\n==============================\nFINAL PERFORMANCE\n==============================")
    print(df.to_string(index=False))


if __name__ == "__main__":
    main()
